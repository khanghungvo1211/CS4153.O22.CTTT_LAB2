package com.example.calculator;

public class HistoryOperation {
    public String operation;
    public String result;

    public HistoryOperation(String operation, String result) {
        this.operation = operation;
        this.result = result;
    }
}
